package ucs_maubin.lm17_team12.lbums.Model;

/**
 * Created by hha on 10/16/17.
 */

public class Tracks {
    Integer track_id;
    String track_name, track_cover, track_link;
    Integer track_genre, track_artist, track_album;

    public Tracks() {}

    public Tracks(Integer track_id, String track_name, String track_cover, String track_link, Integer track_genre, Integer track_artist, Integer track_album) {
        this.track_id = track_id;
        this.track_name = track_name;
        this.track_cover = track_cover;
        this.track_link = track_link;
        this.track_genre = track_genre;
        this.track_artist = track_artist;
        this.track_album = track_album;
    }

    public Integer getTrack_id() {
        return track_id;
    }

    public void setTrack_id(Integer track_id) {
        this.track_id = track_id;
    }

    public String getTrack_name() {
        return track_name;
    }

    public void setTrack_name(String track_name) {
        this.track_name = track_name;
    }

    public String getTrack_cover() {
        return track_cover;
    }

    public void setTrack_cover(String track_cover) {
        this.track_cover = track_cover;
    }

    public String getTrack_link() {
        return track_link;
    }

    public void setTrack_link(String track_link) {
        this.track_link = track_link;
    }

    public Integer getTrack_genre() {
        return track_genre;
    }

    public void setTrack_genre(Integer track_genre) {
        this.track_genre = track_genre;
    }

    public Integer getTrack_artist() {
        return track_artist;
    }

    public void setTrack_artist(Integer track_artist) {
        this.track_artist = track_artist;
    }

    public Integer getTrack_album() {
        return track_album;
    }

    public void setTrack_album(Integer track_album) {
        this.track_album = track_album;
    }
}
