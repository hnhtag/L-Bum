package ucs_maubin.lm17_team12.lbums.DBHandler;

/**
 * Created by hha on 10/20/17.
 */

public class DatabaseName {
    private final String DATABASE_NAME="MusicDB.db";

    public String getDATABASE_NAME() {
        return DATABASE_NAME;
    }
}
