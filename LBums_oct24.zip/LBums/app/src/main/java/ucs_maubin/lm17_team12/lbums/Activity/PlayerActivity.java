package ucs_maubin.lm17_team12.lbums.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import com.ohoussein.playpause.PlayPauseView;

import ucs_maubin.lm17_team12.lbums.R;

public class PlayerActivity extends AppCompatActivity implements MediaPlayer.OnBufferingUpdateListener,MediaPlayer.OnCompletionListener{
    private Toolbar toolbar;
    public Button btn_repeat, btn_prev, btn_next, btn_shuffle;
    PlayPauseView view;
//    TextView realTime, duration;
    SeekBar track_progress;
    public MediaPlayer mediaPlayer;
    Integer mediaFileLength;
    Integer realTimeLength;
    final Handler handler = new Handler();

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    String name, artist,cover,link;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_arrow_back));


        ImageView iv=(ImageView)findViewById(R.id.blurredAlbumart);
        ImageView iv2=(ImageView)findViewById(R.id.track_cover);
        TextView title =(TextView) findViewById(R.id.song_title),
                artistView = (TextView)findViewById(R.id.song_artist);
//        realTime = (TextView)findViewById(R.id.song_elapsed_time);
//        duration = (TextView) findViewById(R.id.song_duration);

        btn_repeat = (Button) findViewById(R.id.repeatTrack);
        btn_prev = (Button) findViewById(R.id.prevBtn);
        btn_next = (Button) findViewById(R.id.nextBnt);
        btn_shuffle = (Button) findViewById(R.id.shuffleBtn);
        view = (PlayPauseView)findViewById(R.id.play_pause_view);
        track_progress = (SeekBar) findViewById(R.id.song_progress);


        track_progress.setMax(99);
        track_progress.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (mediaPlayer.isPlaying()){
                    SeekBar seekbar = (SeekBar)v;
                    int playPosition =(mediaFileLength/100)*seekbar.getProgress();
                    mediaPlayer.seekTo(playPosition);
                }
                return false;
            }
        });



        Intent i =getIntent();
        Bundle myIntentBundle =i.getExtras();

        if (myIntentBundle!=null){

            cover = myIntentBundle.getString("Tracks_cover");
            name = myIntentBundle.getString("Tracks_name");
            artist = myIntentBundle.getString("Tracks_artist");
            link = myIntentBundle.getString("Tracks_link");
            if (cover!=null || cover !=""){

               /* Bitmap resultBmp = BlurBuilder.blur(PlayerActivity.this, BitmapFactory.decodeResource(getResources(),R.drawable.blr));
                blr.setImageBitmap(resultBmp);*/
                Glide.with(PlayerActivity.this).load(cover).into(iv);
                Glide.with(PlayerActivity.this).load(cover).into(iv2);
            }else {
                Glide.with(PlayerActivity.this).load(R.drawable.player_cover).into(iv);
                Glide.with(PlayerActivity.this).load(R.drawable.player_cover).into(iv2);
            }

                title.setText(name);
                artistView.setText(artist);


        } else {
            Glide.with(PlayerActivity.this).load(R.drawable.player_cover).into(iv);
            Glide.with(PlayerActivity.this).load(R.drawable.player_cover).into(iv2);
        }

        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final ProgressDialog mDialog = new ProgressDialog(PlayerActivity.this);
                mDialog.setCancelable(false);
                AsyncTask<String, String, String> TrackPlay = new AsyncTask<String, String, String>() {

                    @Override
                    protected void onPreExecute() {
                        mDialog.setMessage("Please Wait");
                        mDialog.show();
                    }

                    @Override
                    protected String doInBackground(String... params) {
                        try{
                            mediaPlayer.setDataSource(params[0]);
                            mediaPlayer.prepare();
                        }catch ( Exception e){}
                        return "";
                    }

                    @Override
                    protected void onPostExecute(String s) {
                        mediaFileLength = mediaPlayer.getDuration();
//                        realTimeLength = mediaFileLength;
                        realTimeLength=0;
                        if (!mediaPlayer.isPlaying()){
                            mediaPlayer.start();
                            view.toggle();
                        } else {
                            mediaPlayer.pause();
                            view.toggle();
                        }
                        updateSeekBar();
                        mDialog.dismiss();
                    }
                };

//                TrackPlay.execute("http://hein-htet-aung.github.io/l-bum/albums/1_mate_sway/03_mate_sway.mp3");
                TrackPlay.execute(link);

            }
        });
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnBufferingUpdateListener(this);
        mediaPlayer.setOnCompletionListener(this);

    }

    private void updateSeekBar() {
        track_progress.setProgress((int)(((float)mediaPlayer.getCurrentPosition()/mediaFileLength)*100));
        if (mediaPlayer.isPlaying()){
            Runnable updater= new Runnable() {
                @Override
                public void run() {
                    updateSeekBar();
//                    realTimeLength-=1000;
                    /*realTime.setText(String.format("%d:%d",TimeUnit.MILLISECONDS.toMinutes(realTimeLength),
                            TimeUnit.MILLISECONDS.toSeconds(realTimeLength)-
                                    TimeUnit.MILLISECONDS.toSeconds(TimeUnit.MILLISECONDS.toMinutes(realTimeLength))));*/
                }
            };
            handler.postDelayed(updater,1000);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {
        track_progress.setSecondaryProgress(percent);
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        view.toggle();
    }
}

