package ucs_maubin.lm17_team12.lbums.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ucs_maubin.lm17_team12.lbums.Activity.AlbumActivity;
import ucs_maubin.lm17_team12.lbums.Activity.MainActivity;
import ucs_maubin.lm17_team12.lbums.Adapter.HomeArtistAdapter;
import ucs_maubin.lm17_team12.lbums.Adapter.HomeGenreAdapter;
import ucs_maubin.lm17_team12.lbums.Adapter.HomeTop10TrackAdapter;
import ucs_maubin.lm17_team12.lbums.DBHandler.DBHandler;
import ucs_maubin.lm17_team12.lbums.Model.Album;
import ucs_maubin.lm17_team12.lbums.Model.Artist;
import ucs_maubin.lm17_team12.lbums.Model.Genre;
import ucs_maubin.lm17_team12.lbums.Model.Tracks;
import ucs_maubin.lm17_team12.lbums.R;

/**
 * Created by hha on 10/16/17.
 */

public class HomeFragment extends Fragment {

    private List<Tracks> top10TracksList = new ArrayList<>();
    private List<Genre> genreList = new ArrayList<>();
    private List<Artist> artistList = new ArrayList<>();
    private List<Album> albumList = new ArrayList<>();
    private RecyclerView top10Tracks_recyclerView, genre_recyclerView, artist_recyclerView;
    private HomeTop10TrackAdapter top10TrackAdapter;
    private HomeGenreAdapter genreAdapter;
    private HomeArtistAdapter artistAdapter;

    DBHandler dbHandler;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        TextView more_album = (TextView) view.findViewById(R.id.moreAlbum_title);
        more_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), AlbumActivity.class));
            }
        });

        dbHandler = new DBHandler(getActivity());
        //topTenTrack
        top10TracksList = dbHandler.getAllTracks();
        top10Tracks_recyclerView = (RecyclerView) view.findViewById(R.id.top10_tracks_recycler_view);
        top10TrackAdapter = new HomeTop10TrackAdapter(getContext(), top10TracksList);
        top10TrackAdapter.notifyDataSetChanged();

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        top10Tracks_recyclerView.setLayoutManager(mLayoutManager);
        top10Tracks_recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        // recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        top10Tracks_recyclerView.setItemAnimator(new DefaultItemAnimator());
        top10Tracks_recyclerView.setAdapter(top10TrackAdapter);

        //genre
        genreList = dbHandler.getAllGenre();
        genre_recyclerView = (RecyclerView) view.findViewById(R.id.genre_tracks_recycler_view);
        genreAdapter = new HomeGenreAdapter(getContext(), genreList);

        mLayoutManager = new LinearLayoutManager(getContext());
        genre_recyclerView.setLayoutManager(mLayoutManager);
        genre_recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        // recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        genre_recyclerView.setItemAnimator(new DefaultItemAnimator());
        genre_recyclerView.setAdapter(genreAdapter);

        //artist
        artistList = dbHandler.getAllArtist();
        artist_recyclerView = (RecyclerView) view.findViewById(R.id.artist_recycler_view);
        artistAdapter = new HomeArtistAdapter(getContext(), artistList);

        mLayoutManager = new LinearLayoutManager(getContext());
        artist_recyclerView.setLayoutManager(mLayoutManager);
        artist_recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        // recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        artist_recyclerView.setItemAnimator(new DefaultItemAnimator());
        artist_recyclerView.setAdapter(artistAdapter);

        return view;
    }
}