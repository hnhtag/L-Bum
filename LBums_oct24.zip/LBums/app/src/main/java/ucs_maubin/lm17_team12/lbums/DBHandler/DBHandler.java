package ucs_maubin.lm17_team12.lbums.DBHandler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import ucs_maubin.lm17_team12.lbums.Model.Album;
import ucs_maubin.lm17_team12.lbums.Model.Artist;
import ucs_maubin.lm17_team12.lbums.Model.Genre;
import ucs_maubin.lm17_team12.lbums.Model.Tracks;

/**
 * Created by nanyu on 10/23/17.
 */

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = new DatabaseName().getDATABASE_NAME();

    //album table
    private static final String TABLE_Album = "album";

    private static final String ALBUM_ID = "album_id";
    private static final String ALBUM_NAME = "album_name";
    private static final String ALBUM_COVER = "album_cover";
    private static final String ALBUM_TRACKS="album_tracks";

    //genre table
    private static final String TABLE_Genre = "genre";

    private static final String GENRE_ID = "genre_id";
    private static final String GENRE_NAME = "genre_name";
    private static final String GENRE_COVER = "genre_cover";

    //artist table
    private static final String TABLE_Artist = "artist";

    private static final String ARTIST_ID = "artist_id";
    private static final String ARTIST_NAME = "artist_name";
    private static final String ARTIST_COVER = "artist_cover";

    //track table
    private static final String TABLE_Track = "track";

    private static final String TRACK_ID = "track_id";
    private static final String TRACK_NAME = "track_name";
    private static final String TRACK_COVER = "track_cover";
    private static final String TRACK_LINK = "track_link";

    private static final String TRACK_GENRE = "track_genre";
    private static final String TRACK_ARTIST = "track_artist";
    private static final String TRACK_ALBUM="track_album";

    private static final String FOREIGN_TABLE_1 = "genre";
    private static final String FOREIGN_TABLE_1_ID = "genre_id";
    private static final String FOREIGN_TABLE_2 = "album";
    private static final String FOREIGN_TABLE_2_ID = "album_id";
    private static final String FOREIGN_TABLE_3 = "artist";
    private static final String FOREIGN_TABLE_3_ID = "artist_id";


    public DBHandler(Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE_ALBUM = "CREATE TABLE " + TABLE_Album  + "("
                + ALBUM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + ALBUM_NAME + " TEXT, "
                + ALBUM_COVER + " TEXT, "
                +ALBUM_TRACKS+" TEXT )";
        db.execSQL(CREATE_TABLE_ALBUM);
        Log.i("DB","Created Album table");

        String CREATE_TABLE_GENRE = "CREATE TABLE " + TABLE_Genre  + "("
                + GENRE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + GENRE_NAME + " TEXT, "
                + GENRE_COVER + " TEXT )";
        db.execSQL(CREATE_TABLE_GENRE);
        Log.i("DB","Created Genre table");

        String CREATE_TABLE_ARTIST= "CREATE TABLE " + TABLE_Artist  + "("
                + ARTIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + ARTIST_NAME + " TEXT, "
                + ARTIST_COVER + " TEXT )";
        db.execSQL(CREATE_TABLE_ARTIST);
        Log.i("DB","Created Artist table");

        String CREATE_TABLE_TRACK = "CREATE TABLE " + TABLE_Track  + "("
                + TRACK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + TRACK_NAME + " TEXT, "
                + TRACK_COVER + " TEXT, "
                + TRACK_LINK + " TEXT, "
                + TRACK_GENRE + " INTEGER, "
                + TRACK_ARTIST + " INTEGER, "
                + TRACK_ALBUM + " INTEGER, "
                + "FOREIGN KEY (" + TRACK_GENRE + ") REFERENCES " + FOREIGN_TABLE_1 +"("+FOREIGN_TABLE_1_ID+"), "
                + "FOREIGN KEY (" + TRACK_ALBUM + ") REFERENCES " + FOREIGN_TABLE_2 +"("+FOREIGN_TABLE_2_ID+"), "
                + "FOREIGN KEY (" + TRACK_ARTIST + ") REFERENCES " + FOREIGN_TABLE_3 +"("+FOREIGN_TABLE_3_ID+"))";

        db.execSQL(CREATE_TABLE_TRACK);
        Log.i("DB","Created track table");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Album);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Genre);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Artist);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Track);

        // Create tables again
        onCreate(db);
    }


    // Inserting a album
    public void addAlbum(Album album) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ALBUM_NAME, album.getAlbum_name());
        values.put(ALBUM_COVER, album.getAlbum_cover());
        values.put(ALBUM_TRACKS, album.getAlbum_track());

        // Inserting Row
        db.insert(TABLE_Album, null, values);
    }


    // Getting All Album
    public List<Album> getAllAlbums() {
        List<Album> albumList = new ArrayList<Album>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_Album;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Album album = new Album();
                album.setAlbum_id(Integer.parseInt(cursor.getString(0)));
                album.setAlbum_name(cursor.getString(1));
                album.setAlbum_cover(cursor.getString(2));
                album.setAlbum_track(Integer.parseInt(cursor.getString(3)));

                // Adding student to list
                albumList.add(album);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return student list
        Log.i("  album Szie", String.valueOf(albumList.size()));
        int a=albumList.size();
        for (int i=0 ; i<a;i++){
            Log.i("  album ", albumList.get(i).getAlbum_name() + "  \n");
        }

        return albumList;
    }


    // Inserting a Genre
    public void addGenre(Genre genre) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(GENRE_NAME, genre.getGenre_name());
        values.put(GENRE_COVER, genre.getGenre_cover());

        // Inserting Row
        db.insert(TABLE_Genre, null, values);
    }


    // Getting All genre
    public List<Genre> getAllGenre() {
        List<Genre> genreList = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_Genre;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Genre genre = new Genre();
                genre.setGenre_id(Integer.parseInt(cursor.getString(0)));
                genre.setGenre_name(cursor.getString(1));
                genre.setGenre_cover(cursor.getString(2));

                // Adding student to list
                genreList.add(genre);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return student list

        Log.i("Genre Szie", String.valueOf(genreList.size()));
        int a=genreList.size();
        for (int i=0 ; i<a;i++){
            Log.i("  album ", genreList.get(i).getGenre_name() + "  \n");
        }

        return genreList;
    }


    // Inserting a artist
    public void addArtist(Artist artist) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ARTIST_NAME, artist.getArtist_name());
        values.put(ARTIST_COVER, artist.getArtist_cover());

        // Inserting Row
        db.insert(TABLE_Artist, null, values);
    }


    // Getting All artist
    public List<Artist> getAllArtist() {
        List<Artist> artistList = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_Artist;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Artist artist = new Artist();
                artist.setArtist_id(Integer.parseInt(cursor.getString(0)));
                artist.setArtist_name(cursor.getString(1));
                artist.setArtist_cover(cursor.getString(2));

                // Adding student to list
                artistList.add(artist);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return student list

        Log.i("artist Size", String.valueOf(artistList.size()));

        int a=artistList.size();
        for (int i=0 ; i<a;i++){
            Log.i("  album ", artistList.get(i).getArtist_name() + "  \n");
        }

        return artistList;
    }

    // Inserting a track
    public void addTrack(Tracks tracks) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TRACK_NAME, tracks.getTrack_name());
        values.put(TRACK_COVER, tracks.getTrack_cover());
        values.put(TRACK_LINK, tracks.getTrack_link());
        values.put(TRACK_GENRE, tracks.getTrack_genre());
        values.put(TRACK_ARTIST, tracks.getTrack_artist());
        values.put(TRACK_ALBUM, tracks.getTrack_album());

        // Inserting Row
        db.insert(TABLE_Track, null, values);
    }


    // Getting All Tracks
    public List<Tracks> getAllTracks() {
        List<Tracks> tracksList = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_Track;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Tracks tracks = new Tracks();
                tracks.setTrack_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex(TRACK_ID))));
                tracks.setTrack_name(cursor.getString(cursor.getColumnIndex(TRACK_NAME)));
                tracks.setTrack_cover(cursor.getString(cursor.getColumnIndex(TRACK_COVER)));
                tracks.setTrack_link(cursor.getString(cursor.getColumnIndex(TRACK_LINK)));
                tracks.setTrack_genre(cursor.getInt(cursor.getColumnIndex(TRACK_GENRE)));
                tracks.setTrack_artist(cursor.getInt(cursor.getColumnIndex(TRACK_ARTIST)));
                tracks.setTrack_album(cursor.getInt(cursor.getColumnIndex(TRACK_ALBUM)));

                // Adding student to list
                tracksList.add(tracks);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return student list

        Log.i("track Szie", String.valueOf(tracksList.size()));

        int a=tracksList.size();
        for (int i=0 ; i<a;i++){
            Log.i("  album ", tracksList.get(i).getTrack_name() + "  \n");
        }

        return tracksList;
    }



}
