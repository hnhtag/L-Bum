package ucs_maubin.lm17_team12.lbums.Model;

/**
 * Created by hha on 10/16/17.
 */

public class Genre {
    Integer genre_id;
    String genre_name;
    String genre_cover;

    public Genre() {}

    public Genre(Integer genre_id, String genre_name, String genre_cover) {
        this.genre_id = genre_id;
        this.genre_name = genre_name;
        this.genre_cover = genre_cover;
    }

    public Integer getGenre_id() {
        return genre_id;
    }

    public void setGenre_id(Integer genre_id) {
        this.genre_id = genre_id;
    }

    public String getGenre_name() {
        return genre_name;
    }

    public void setGenre_name(String genre_name) {
        this.genre_name = genre_name;
    }

    public String getGenre_cover() {
        return genre_cover;
    }

    public void setGenre_cover(String genre_cover) {
        this.genre_cover = genre_cover;
    }
}
