package ucs_maubin.lm17_team12.lbums.Model;

/**
 * Created by hha on 10/20/17.
 */

public class Album {
    Integer album_id;
    String album_name, album_cover;
    Integer album_track;

    public Album() {}

    public Album(Integer album_id, String album_name, String album_cover, Integer album_track) {
        this.album_id = album_id;
        this.album_name = album_name;
        this.album_cover = album_cover;
        this.album_track = album_track;
    }

    public Integer getAlbum_id() {
        return album_id;
    }

    public void setAlbum_id(Integer album_id) {
        this.album_id = album_id;
    }

    public String getAlbum_name() {
        return album_name;
    }

    public void setAlbum_name(String album_name) {
        this.album_name = album_name;
    }

    public String getAlbum_cover() {
        return album_cover;
    }

    public void setAlbum_cover(String album_cover) {
        this.album_cover = album_cover;
    }

    public Integer getAlbum_track() {
        return album_track;
    }

    public void setAlbum_track(Integer album_track) {
        this.album_track = album_track;
    }
}
